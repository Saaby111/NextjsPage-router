export default function About() {
  return (
    <div>
      <h1>About Us</h1>
      <p>This is a sample e-commerce app built with Next.js and TypeScript.</p>
    </div>
  );
}
