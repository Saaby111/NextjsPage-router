export default function CartPage() {
  return <h1>Your Cart</h1>;
}
